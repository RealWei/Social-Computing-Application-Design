101062225 曾振瑋 Lab2-2

/////////////////////////////////////
//                                 //
//      Explanation of my work     //
//                                 //
/////////////////////////////////////

I modified echo_robot.py to complete the assignment.
Just search if user input matches any predefined regular expressions, then reply one of the corresponding responses.
If none of predefined regular expressions matches, reply a sorry message.

I also added some predefined responses in "sentences" file.


/////////////////////////////////////
//                                 //
//      Problems encountered       //
//                                 //
/////////////////////////////////////

1.
I thought it will be hard to do at the first place. I chatted with robot back in time when MSN, Yahoo messenger are still popular. I felt cool when I was a kid, I finally understand how it is implemented thanks to this assignment.

2.
I have to review regular expression every single time. But this time is relatively simple compare to expressions used in compiler course.
